<?php

echo "<?php\n";
?>

echo '这是' . Yii::$app->params['addon']['name'] . ' <?= $appID ?> 页面';