<?php

return [
    'Home' => 'home',
    'About' => 'about',
    'Contact' => 'contact',
    'Signup' => 'signup',
    'Login' => 'login',
];